# 官方技术依据



访问日 2026-10-11，仅以官方 primary source 核验技术概念。页面为教学架构，不要求学员使用这些具体供应商。

1. [Google Analytics：URL builders / campaign data](https://support.google.com/analytics/answer/10917952?hl=en-uk)：UTM 用于营销活动来源归类；至少一致使用 source / medium / campaign。
2. [Google Analytics：Traffic-source dimensions](https://support.google.com/analytics/answer/11242870?hl=en)：解释渠道来源与 medium 的含义。
3. [Expo：Overview of linking, deep links, Android App Links, and iOS Universal Links](https://docs.expo.dev/linking/overview/)：说明 deep links 与 App/Universal Links；App 已安装和未安装有不同打开行为。
4. [Stripe：Receive events / Webhooks](https://docs.stripe.com/webhooks)：事件会重试，可能重复或乱序；确认事件签名并处理重复事件。此来源支持事件投递边界，不代表 App 已接 Stripe。
5. [Stripe：Idempotent requests](https://docs.stripe.com/api/idempotent_requests)：相同逻辑请求使用同一幂等键可以安全重试；外部服务的保留期限不替代自己的奖励账本。
6. [Stripe：Refunds](https://docs.stripe.com/refunds)：退款有独立事件与状态，需要跟踪更新。Affiliate 如何冲减佣金是本课设计建议与业务条款，不是 Stripe 的自动分佣保证。
