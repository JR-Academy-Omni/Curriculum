# 增长如何接到网站、App与后台

按当前实验需要选择，不是全部上齐才能增长。最小闭环通常是：入口 → 获值事件 → 核验 → 结果回读。

| 层 | 负责什么 | 最小字段 / 判定 |
|---|---|---|
| 渠道 Campaign / UTM | 哪个渠道和素材带来访问 | utm_source / utm_medium / utm_campaign；需要区分素材加utm_content |
| 邀请 Referral URL | 谁邀请、哪场实验 | 不含邮箱/姓名的opaque invite token，服务端解析邀请人、活动与有效期；App deep link与网站落地页沿用既有路由 |
| 身份 Identity | 同一个用户跨会话行动 | anonymous_id → user_id合法关联；不能拿UTM当身份；跨设备盲区如实说明 |
| 事件 Events | 用户实际做到哪一步 | event_id、user_id或匿名id、campaign_id、invite_id、时间、动作对象；客户端交互与服务端事实分开 |
| 核验 Verification | 谁符合奖励资格 | 新用户、非自邀、活动有效、用户已定义的奖励条件；注册去重、重放不重复计数 |
| 奖励账本 Reward Ledger | 准确发放与撤销 | 按活动+双方身份+奖励类型唯一去重；pending/verified/granted/reversed；事务或原子操作保障一致性 |
| 自动化 Automation | 事件发生后的动作 | event → rule → action → read-back；幂等重试、限频、预算、退出和停止条件 |
| 配置 Super Admin | 经营者可调实验 | campaign、渠道、资格、奖励额度、预算、时间窗、开关、规则版本、操作者审计；秘密只在服务端 |
| 读数 Dashboard | 看哪条箭头变好 | 同一邀请队列：访问→注册→获值→奖励；每步去重人数、转化窗口、工时与成本 |
| 伙伴 Affiliate | 付费推荐的佣金结算 | partner_id→订单→支付确认→退款窗→有效净成交→结算；点击或普通邀请不直接生成佣金 |

UTM可以被用户更改，因此只作为渠道标签；奖励不信任前端传来的邀请人或余额。自定义query示例只能用于未上线的新演示，不能更改现有生产URL形状。涉及个人信息与cookie按用户实际地区、同意状态与数据规则实现。

薅羊毛课堂示例：现有默认5雷达；成功邀请朋友注册新匠人账户+2雷达；任务奖励由本机进度计算，尚不是服务端账本。分享图片面板正常关闭会记录一次分享，不能证明送达。新用户完成画像+创建首个雷达可以作为候选Activation定义，但要先验证它代表用户获值。提醒当前为打开App时扫描匹配，不等于闭App远程推送。

建议分两支：邀请来源 invite_opened → 注册确认 signup_verified → 奖励 reward_granted → 回读 reward_seen；另一支从注册确认追踪首次获值 first_value_completed 和后续回访。薅羊毛现行条件是成功邀请注册，首次获值是独立观测，不是这次新增发奖前置条件。这些事件名为教学设计，尚未证明后台已采集。用户明确选择其他奖励条件时才相应调整实现。

官方依据见[infrastructure-sources.md](infrastructure-sources.md)；实际实施前核对当前所用平台的版本化文档、现有数据库和路由。
