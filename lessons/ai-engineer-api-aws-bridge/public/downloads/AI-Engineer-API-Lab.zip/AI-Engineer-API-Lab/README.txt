API Lab
macOS: python3 lab/server.py
Windows: py lab/server.py
Open http://127.0.0.1:8047/
Stop: Ctrl+C
