# 企业 AI 自动化实战营 · 课堂宣传图

status: visually-reviewed local draft; not published
surface: course-promotional-visual
brand: jr-academy
register: A-editorial
extends: jr-academy-brand/DESIGN.md, APPLICATIONS.md, POSTER_DESIGN.md, COURSE_DESIGN.md
facts: enterprise-ai-automation-bootcamp/public/outline.json
channel: website / downloadable classroom campaign
size: 1600 x 900, 16:9, each independently composed from its own scene

Audience: small business owners and professionals seeking practical enterprise AI work. One task: illustrate demonstration, hands-on practice and review. CTA: view course outline at the existing fixed course URL. No invented cohort date, venue, instructor, class size promise, student testimonial or enrolment availability.

Confirmed: five lessons, ten hours, early A$899, standard A$1,099. Retain English technical terms. Colour/spacing/controls follow JR Register A. Original logo is assets/logo-official-black.svg (SHA256 04fc6e3071c34cade0f63589ba2a053b709465e59f409e991edd00ece999d0fe), directly embedded without model reconstruction. Partner logos remain in the existing website section.

Image Model supplies only fictional classroom scenes. There are no real software screenshots, model-generated JR logos, confirmed instructor portraits or real student evidence. Each exported image has a visible concept label; the website also explains the course format is subject to confirmed arrangements. Actual outcomes remain linked separately through the existing full work samples.

Sources: classroom-campaign.html + classroom-campaign.json + three scene PNGs. Exact prompts in PROMPTS.md. Export original PNGs at 1600x900. Downloads include self-contained editable HTML sources with embedded scene and original logo, preserving geometry. No media API keys, local CI or deployment.
