---
name: jd-company-skill-extractor
description: 给一个 JD（必填）+ 目标公司（可选）→ 反推这家公司真实看重的 **hard skills / soft skills / 技术栈**，再跟用户当前简历 cross-check 找 fit gap，输出可直接照抄改简历的 bullet 改写建议。**核心价值**：JD 字面 ≠ 公司真实在用 — 通过 LinkedIn 现任/离职员工 profile + 公司技术 blog + GitHub 反推真实 stack，避免学员只背 JD 关键词去面试结果被深挖问倒。Use when (1) 学员选定目标公司 JD 准备投递 / 改简历；(2) 已投递但被秒拒，需要诊断 fit gap；(3) 一家公司多个相似岗位要做 skill 矩阵对比；(4) 跨公司同岗位对比（甲方 vs 乙方 / 大厂 vs startup）；(5) 准备面试反向问问题（"我注意到你们用 X..."）。**前置依赖**：用户简历 Skills + Experiences section（gap 模式必需）。**红线**：不编造公司真实未公开的技术栈 / 不承诺 Offer / 不假装 LinkedIn 私密数据。
allowed-tools: Read, Write, Edit, Glob, Grep, Bash, WebFetch, WebSearch
---

# JD 与公司 Skill 反推（求职端 · 简历精准化）

> **解决一个最常见的求职错觉**：学员把 JD 关键词原样抄进简历 → 面试官一深挖立刻露馅。原因：**JD 是 HR 写的「招聘画像」，公司真实在用的栈往往跟 JD 关键词偏差 30-60%。**
>
> 本 skill 用 **JD + LinkedIn + 公司技术 blog + GitHub** 四源交叉，反推这家公司**真实在用什么 + 重点考核什么 + 软性看什么人**，再跟用户简历 cross-check 找 gap，输出可直接照抄的 bullet 改写。
>
> 配合 [[s23c-linkedin-recon]] 调查法（讲座 page=32）+ [[s22-no-experience-path]] 4 路径用。

---

## 在求职辅导流里的位置

本 skill 是**简历精准化阶段**的核心 skill，跟前后串成完整求职链路：

| 阶段 | Skill | 输入 → 输出 |
|------|-------|------------|
| 1️⃣ 简历底稿 | （手写 / Bootcamp 模板） | 通用版简历 |
| 2️⃣ 目标公司选定 | 学员手选 | JD + 公司名 |
| **3️⃣ JD/公司反推 ⭐** | **本 skill** | **Skill 矩阵 + Fit Gap + Bullet 改写** |
| 4️⃣ 简历润色 | （AI 简历润色 skill，另立） | 投递版简历 |
| 5️⃣ 内推话术 | referral-pitch skill | LinkedIn 私信草稿 |
| 6️⃣ 面试题预测 | interview-q-predictor | 30 道公司专属题 |

不要跳过本 skill 直接进润色 — 没有 fit gap 分析，润色出来是套话简历。

---

## 5 个 mode（按场景选）

| Mode | 用在 | 输入 | 输出 |
|------|------|------|------|
| **analyze** | 选定 JD 后第一步 | JD 全文 + 公司名（可选） | Skill 矩阵 + 公司技术偏好 + Soft Skills |
| **gap** | 有简历底稿要诊断 | analyze 结果 + 用户简历 | Fit Gap 报告（缺什么 / 该突出什么） |
| **rewrite** | 拿到 gap 要落到 bullet | gap 结果 + 选 3 段经验 | 3-5 条可直接抄的 bullet 改写 |
| **linkedin-recon** | 单独反推公司技术栈 | 公司名 + LinkedIn URL | 真实技术栈清单（含信源） |
| **compare** | 多 JD / 多公司对比 | 2-5 个 JD | 横向对比矩阵 + 优先级建议 |

**串行用法**（推荐）：analyze → gap → rewrite，30 分钟跑完一个目标公司。

---

## Mode 1 · analyze（核心模式 · 必读）

### 输入

```yaml
jd_text: |  # 必填，JD 全文，包含 Requirements / Responsibilities / About Company
  ...JD 全文 paste...
company_name: "<公司名>"   # 可选，给了就跑 linkedin-recon 交叉验证
company_url: "<官网/LinkedIn>"  # 可选
seniority_target: "Mid"  # Junior / Mid / Senior / Lead，影响 must-have 权重
```

### 处理步骤（不可跳过）

1. **JD 字面解析**（5 min）
   - 抓 Requirements 段所有名词短语 → 候选 hard skill list
   - 区分 must-have（"required" / "must" / "X+ years"）vs nice-to-have（"plus" / "bonus" / "preferred"）
   - 抓 Responsibilities 段动词 → 推断日常工作内容
   - 抓 About Company 段 → 公司类型（甲方 / 乙方 / startup / 大厂）

2. **公司技术栈反推**（10 min · 若提供 company_name）
   - LinkedIn 调查法（参考讲座 page=32）：
     - 搜 "{company} AI Engineer / ML Engineer / LLM Engineer"
     - 抓 5-10 个现任 profile · 提取 Experience 共同关键词
     - Past Employees → 看离职跳哪 + Experience 写的真实 stack
   - 公司技术 blog / Engineering blog → 真实在写什么
   - 公司 GitHub org → 看 repo language / dep / topic tags
   - **交叉验证**：JD 关键词在 LinkedIn 出现率 < 30% 的 → 标 "JD 装饰词，面试不会深挖"

3. **Soft Skills 反推**（5 min）
   - JD 描述 → 抓 "collaborate / fast-paced / ownership / proactive / mentor" 等
   - 公司类型映射：
     - 甲方产品公司 → DAU 思维 / 数据驱动 / A/B iteration speed
     - 乙方 consulting → 抗压 / 多客户 / 快速适配 / 客户沟通（**参考 page=32 现实问题**）
     - Startup → 全栈 / 主动 / scope 切换 / 0 → 1
     - 大厂 → 规模 / 跨团队对齐 / 流程 / 资深 mentoring

4. **输出 Skill 矩阵**（结构化）

### 输出格式

```markdown
# JD 反推报告 · {Company} · {Job Title}

## A · Hard Skills 矩阵（按权重排序）

### 🔴 Must-Have（不命中 = 不通过 Resume Screen）
| Skill | JD 出现 | LinkedIn 验证 | 优先级 | 备注 |
|-------|--------|--------------|--------|------|
| RAG (hybrid search) | 3 次 | 8/10 profile 有 | ⭐⭐⭐ | 必命中 |
| LangGraph | 2 次 | 6/10 profile 有 | ⭐⭐⭐ | 公司主 Agent 框架 |
| AWS Bedrock | 1 次 | 9/10 profile 有 | ⭐⭐⭐ | 实际 hosting 选型 |
| Python | 5 次 | — | ⭐⭐ | 基线 |
| ... |

### 🟡 Nice-to-Have（命中加分）
| Skill | JD 出现 | LinkedIn 验证 | 优先级 |
|-------|--------|--------------|--------|
| MCP Server | 0 次 | 4/10 profile 有 | ⭐⭐ |
| RAGAS eval | 0 次 | 3/10 profile 有 | ⭐⭐ |
| ... |

### ⚪ JD 装饰词（面试不会深挖，简历可不放）
- "AI/ML expertise" — 太泛，写具体技术替代
- "5+ years experience" — Mid 岗写 18 个月 production 经验就够
- "Strong communication" — 用 ✓ Behavioral 题答出来

## B · 技术栈关键词清单（按权重）

**核心栈**（必写进 Skills section）：
- Python · Anthropic SDK · LangGraph · AWS Bedrock · pgvector

**周边栈**（写经验描述时带）：
- Cohere Rerank · RAGAS · LangSmith · Streaming SSE

**边缘栈**（有就写，没有不强求）：
- Mem0 · MCP Server · Computer Use

## C · 公司技术偏好（LinkedIn + Blog 反推）

- **主 LLM 供应商**：Anthropic（非 OpenAI · 从 4 个工程师 profile 推断）
- **Hosting**：AWS Bedrock（公司 blog 2025-Q3 提到）
- **Agent 框架**：自研 + LangGraph 混合
- **数据库**：Postgres 系（pgvector + pg_trgm）
- **Cost 敏感度**：高（公司是 startup · LinkedIn 多人写 cost optimization）

## D · Soft Skills（公司类型驱动）

- 公司类型推断：**乙方 consulting（Series B startup）**
- 必命中：抗压 / 多客户切换 / 快速适配 / 客户沟通
- 加分：fast PoC / 0-1 / 主动 escalate
- 面试预备（参考讲座 page=32）：
  > "How do you handle pressure / long hours / tight deadlines" — 不要回避，给 SOP（优先级 / 跟 PM 重新对齐 scope / 主动 escalate）

## E · 真实在用 vs JD 字面 · Gap 表

| JD 写的 | LinkedIn 反推的真实 | 你简历该写的 |
|---------|-------------------|------------|
| "LLM expertise" | Claude Sonnet 4.6 主力 · GPT-4o backup | "Production-grade Claude Sonnet integration via Bedrock" |
| "RAG experience" | hybrid search + Cohere Rerank | "Hybrid-search RAG (BM25 + pgvector + Cohere Rerank v3), RAGAS 0.91" |
| "Agent system" | LangGraph multi-agent | "Designed 5-agent LangGraph workflow for {domain}" |
| ... |

## F · 信源（强制透明）

- JD URL：[link]
- LinkedIn 反推：5 个现任 + 2 个离职 profile（截图编号 #L01-L07）
- 公司技术 blog：{URL}（2025-10-15 / 2025-12-03 两篇）
- GitHub org：{URL}（3 个 public repo · 主语言 Python + TypeScript）
- 数据采集日期：YYYY-MM-DD
```

---

## Mode 2 · gap（fit 诊断）

### 输入

- analyze 输出文件 `analyze-{company}.md`
- 用户简历 Skills + Experiences section（markdown / pdf 解析后的文本）

### 输出

```markdown
# Fit Gap 报告 · {Company} · {Candidate Name}

## ✅ 已命中（在 Resume Screen 阶段不会被刷）

- Python · Anthropic SDK · pgvector · RAGAS · LangSmith

## 🟡 弱命中（简历有提但深度不够）

- **RAG**：你写 "Implemented RAG" → 应改 "Hybrid-search RAG (BM25 + pgvector + Cohere Rerank v3) over Xk docs, RAGAS Faithfulness 0.91"
- **LangGraph**：你写 "Familiar with LangGraph" → 应改 "Designed 4-agent LangGraph workflow with reflection loop, factual error 18% → 3%"

## 🔴 完全缺失（必须想办法补 · 至少 2 周）

- **MCP Server**：公司 LinkedIn 4/10 profile 提到 · 你简历 0 提
  → 补救：1 周内写一个 MCP Server demo（filesystem 或 DB 暴露给 Claude Code），GitHub repo 发出来
- **Cost Optimization**：公司 startup cost 敏感 · 你简历无量化 cost 数据
  → 补救：把现有 RAG 项目跑一遍 tiktoken cost 估算，加进 bullet

## ⚠️ 你简历 overclaim 的（面试会被深挖问倒）

- 你写 "Expert in LLM fine-tuning" 但项目没有 fine-tune 经验
  → 改成 "Working knowledge of LoRA / QLoRA, evaluated for {use case}（决定不上 fine-tune 转 RAG）"
- 你写 "Built multi-agent system" 但实际只有 single agent + tool calling
  → 改成 "Built single agent with 6 tools (function calling) for {task}"

## 整体 Fit 分（量化）

| 维度 | 命中率 | 评分 |
|------|--------|------|
| Hard Skills | 6/12 | 50% |
| 技术栈核心栈 | 4/5 | 80% |
| Production Eval / Cost | 2/4 | 50% |
| Soft Skills (公司类型) | 估 70% | — |
| **整体推荐**：**Mid 岗投递** · 简历改写后 Resume Screen 通过率约 35-50% |
```

**红线**：fit 分 < 40% → 建议先做 2 周补救项目再投，不要硬投浪费机会。

---

## Mode 3 · rewrite（bullet 改写）

输入 gap 结果 + 学员挑的 3 段经验 → 输出 3-5 条可直接照抄的 bullet 改写。

### 输出格式

```markdown
# Bullet 改写建议 · {Company} 投递版

## 经验 1：{原 bullet}

❌ Before:
> "Built a chatbot using OpenAI API and LangChain for customer support."

✅ After（命中 {Company} 反推关键词）:
> "Architected hybrid-search RAG (BM25 + pgvector + Cohere Rerank v3) over 12k internal docs for L1 customer support — RAGAS Faithfulness 0.89, p95 latency < 1.2s, $0.004/query via AWS Bedrock + LiteLLM gateway, 41% L1 ticket deflection."

**命中**：Hybrid Search ✓ · pgvector ✓ · Cohere Rerank ✓ · Bedrock ✓ · LiteLLM ✓ · RAGAS ✓ · Cost ✓ · Latency ✓ · 量化结果 ✓

## 经验 2 / 3 ...
（同上格式）

## 红线警告
- 改写后的 bullet 必须**真的对应你做过的事** — 把模糊的事说精确，不是编造没做过的
- 数字必须真实 — 如果原来没量化，补救方法：今晚回去跑 tiktoken / LangSmith 算出来真实数字再写
- 工具名必须用过 — 没用过的 Cohere Rerank 不能写
```

---

## Mode 4 · linkedin-recon（单独反推公司技术栈）

输入公司名 → 跑完整 LinkedIn 调查（讲座 page=32 5 步法）→ 输出技术栈清单 + 信源。

适合：还没选定 JD 但在调研多家目标公司 / 准备给某场会议提问。

---

## Mode 5 · compare（多 JD 对比）

输入 2-5 个 JD（同公司不同岗位 / 多公司同岗位）→ 横向矩阵 + 优先级建议。

适合：拿到 3 个面试邀请要决定先准备哪家 / 一家公司同时投两个岗位要选哪个。

---

## 🚨 红线（必须遵守）

1. **不编造未公开的公司技术栈** — 所有反推必须给信源（LinkedIn URL / blog URL / GitHub repo）
2. **LinkedIn 私密数据不抓** — 只用公开 profile，不假装能看到付费用户 paywall 数据
3. **不承诺 Offer / 不承诺通过率** — 通过率给区间（"约 35-50%"），不写"保证通过"
4. **rewrite 不替学员编虚构项目** — 只把模糊的事说精确，不能把没做过的写成做过
5. **数字不假装精确** — 用区间 / "约" / 标"实际跑过 tiktoken 再填"
6. **Soft skill 不写性别 / 年龄 / 学校歧视** — 反歧视红线
7. **公司类型判断要给信源** — 不能说"这是 startup"却没提为什么这么判断
8. **不替代用户人工 LinkedIn 调查** — skill 给框架，学员自己点开 profile 看真实内容（隐私 + 准确度）

---

## 配合的下游 skill（不要自己做，调用）

- 简历润色：跑完 rewrite → 用 resume-polish skill 整体过一遍语病
- 内推话术：拿到 fit 分 → 用 referral-pitch skill 写给内推人的 LinkedIn 私信
- 面试题预测：rewrite 后 → 用 interview-q-predictor 生成 30 道公司专属题
- 反向问问题：用 analyze 的"E · Gap 表"里"真实在用"那列 → 面试时反向问"我注意到你们用 X..."

---

## 输出文件落盘约定

每跑一次 analyze 产出文件到：

```
curriculum/jd-analyses/{company}-{role}-{YYYYMMDD}/
├── jd-raw.txt          # JD 原文备份
├── analyze.md          # Mode 1 输出
├── gap.md              # Mode 2 输出（如跑过）
├── rewrite.md          # Mode 3 输出（如跑过）
└── sources.json        # LinkedIn / blog / GitHub URL 信源清单
```

**目的**：
- 简历投递历史可追溯（防止同公司不同岗位写偏）
- 多家公司对比 mode 4 用得上
- 半年后回看自己的简历演化轨迹

---

## 反原则（这些事 skill 不做）

- ❌ 不直接生成最终简历 — 那是 resume-polish skill 的工作
- ❌ 不模拟面试 — 那是 interview-q-predictor + mock-interview skill 的工作
- ❌ 不替学员投递 — 投递是学员自己决定的动作
- ❌ 不抓 LinkedIn 私密数据 / 不抓 Glassdoor 付费内容 — 只用公开信息
- ❌ 不为公司"加分"或"减分" — skill 是中立分析工具，不替学员决定要不要投这家
- ❌ 不写"这家公司钱多" / "这家公司加班少" — 不评价公司，只分析技术 fit
